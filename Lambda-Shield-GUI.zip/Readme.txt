This is an example of how to use a front end with the Lambda Shield for Arduino(R).

	1) - Install "Lambda-Shield-GUI.ino" to your Arduino(R) and make sure that
	     you have the correct shield attached.

	2) - Install "Lambda_Shield_for_Arduino_GUI.msi" to your windows computer.

	3) - Run the "Lambda Shield for Arduino" shortcut from your desktop.

For troubleshooting and support, please visit http://www.bylund-automotive.com/